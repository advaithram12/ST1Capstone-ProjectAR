

###This code is written based on the fact that there is a text file called "file.txt" in the same folder the code is in.

#Advaith Ramakrishnan
#u3261011


import tkinter as tk
from tkinter import *
from tkinter import messagebox

word = 0
ewords = []

def add_word_entry():
    entry = tk.Entry(word_entry_frame)
    entry.pack()
    ewords.append(entry)

def show_message_box(message):
    messagebox.showinfo(" ", message)

def file_write():
    num_words = int(words.get())
    filename = "file.txt"

    with open(filename, 'a') as file:
        word = 0
        for i in range(num_words):
            if i < word:
                word = ewords[i].get()
                file.write(word + '\n')
            else:
                break

        words.delete(0, tk.END)  # Clear the word count entry
        for entry in ewords:
            entry.delete(0, tk.END)  # Clear the word entry fields

        result_label.config(text=f"{num_words} words have been written to {filename}")

        message = f"{num_words} words have been written to {filename}"
        result_label.config(text=message)
        show_message_box(message)
def num_words():
    global word
    word = int(words.get())
    for i in range(word):
        add_word_entry()

# Create the main application window
window = tk.Tk()
window.title("Word List File Reader")

# Create and pack widgets
label1 = Label(window, text="How many words would you like to write to the file: ")
label1.pack()

words = Entry(window)
words.pack()

button1 = Button(window, text="Enter Words", command=num_words)
button1.pack()

frame1 = Frame(window)
frame1.pack()

button2 = Button(window, text="Write to file", command=file_write)
button2.pack()

result_label = Label(window, text="")
result_label.pack()

window.mainloop()
