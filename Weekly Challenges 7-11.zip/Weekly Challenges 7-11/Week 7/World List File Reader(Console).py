
#Advaith Ramakrishnan
#u3261011


#CODE TO WRITE WORDS INTO FILE


#word = int(input("How many words would you like to write to a file: "))
#file = "file.txt"
#with open(file,'w') as file:
 #   for i in range(word):
 #       num_words = input(f"Enter word {i + 1} :")e
 #       file.write(num_words + '\n')

#print(f"{file} words have been written to {file}")



#CODE TO OPEN FILE

def average(w):
    total = sum(len(w) for q in w )
    return total / len(w)

file = "file.txt"
with open(file,"r") as file:
    w = file.read().split()
    num = len(w)
    long = max(w, key=len)
    average = average(w)


print(f"Number of words: {num}")
print(f"Longest word: {long}")
print(f"Average: {average}")

