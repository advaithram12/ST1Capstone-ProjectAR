#Advaith Ramakrishnan
#u3261011

class Library:
    def __init__(self, item_name, author, publisher):
        self.item_name = item_name
        self.author = author
        self.publisher = publisher

    def get_item_name(self):
        return self.item_name

    def set_item_name(self, new_item_name):
        self.item_name = new_item_name

    def get_author(self):
        return self.author

    def set_author(self, new_author):
        self.author = new_author

    def get_publisher(self):
        return self.publisher

    def set_publisher(self, new_pub):
        self.publisher = new_pub

class Book(Library):
    def __init__(self, title, author, publisher, num_pages, hard_copy, ebook):
        super().__init__(title, author, publisher)
        self.num_pages = num_pages
        self.has_hard_copy = hard_copy
        self.has_ebook = ebook

    def get_num_pages(self):
        return self.num_pages

    def set_num_pages(self, new_num_pages):
        self.num_pages = new_num_pages

    def hard_copy(self):
        return self.has_hard_copy

    def ebook(self):
        return self.has_ebook

# Tester program
if __name__ == "__main__":
    # Create a Book instance
    book1 = Book("Sample Book", "Author Name", "Publisher Inc.", 300, True, True)

    # Access and display book information
    print("Book Information:")
    print(f"Title: {book1.get_item_name()}")
    print(f"Author: {book1.get_author()}")
    print(f"Publisher: {book1.get_publisher()}")
    print(f"Number of Pages: {book1.get_num_pages()}")
    print("Has Hard Copy:", "Yes" if book1.hard_copy() else "No")
    print("Has eBook:", "Yes" if book1.ebook() else "No")
