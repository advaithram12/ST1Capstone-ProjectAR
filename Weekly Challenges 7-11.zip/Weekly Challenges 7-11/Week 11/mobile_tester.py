#Library
import tkinter as tk
from mobile import MobilePhone
from tkinter import messagebox

#Introduce Class for Mobile Testing
class MobileTester:
    def __init__(self, window):
        self.window = window
        self.window.title("Mobile Phone Information")

        self.phone = MobilePhone("", "", 0.0) # Link to other file with mobile phone class

        self.widget()
    
    def widget(self):
        # Labels
        tk.Label(self.window, text="Manufacturer:").pack()
        self.manufacturer_entry = tk.Entry(self.window)
        self.manufacturer_entry.pack()

        tk.Label(self.window, text="Model:").pack()
        self.model_entry = tk.Entry(self.window)
        self.model_entry.pack()

        tk.Label(self.window, text="Retail Price:").pack()
        self.price_entry = tk.Entry(self.window)
        self.price_entry.pack()

        # Buttons
        tk.Button(self.window, text="Create Phone Details", command=self.c_phone).pack()
        tk.Button(self.window, text="Update Phone Details", command=self.u_phone).pack()
        tk.Button(self.window, text="Display Information", command=self.display).pack()

    def c_phone(self): # what should the code do if user wants to create a new phone
        manufacturer = self.manufacturer_entry.get()
        model = self.model_entry.get()
        price = float(self.price_entry.get())
        self.phone = MobilePhone(manufacturer, model, price)
        self.clear_entries()

    def u_phone(self):# what should the code do if user wants to update after object has been created
        manufacturer = self.manufacturer_entry.get()
        model = self.model_entry.get()
        price = float(self.price_entry.get())
        self.phone.set_manufact(manufacturer)
        self.phone.set_model(model)
        self.phone.set_retail_price(price)
        self.clear_entries()

    def display(self):# Information to display if user wants to display information after creating object
        info = f"Manufacturer: {self.phone.get_manufact()}\nModel: {self.phone.get_model()}\nRetail Price: ${self.phone.get_retail_price()}"

        tk.messagebox.showinfo("Phone Information", info)

    def clear_entries(self):
        self.manufacturer_entry.delete(0, tk.END)
        self.model_entry.delete(0, tk.END)
        self.price_entry.delete(0, tk.END)

if __name__ == "__main__":
    window = tk.Tk()
    app = MobileTester(window)


    
    window.mainloop()
