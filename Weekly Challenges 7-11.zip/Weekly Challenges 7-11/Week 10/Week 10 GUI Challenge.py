#Advaith Ramakrishnan
#u3261011

import tkinter as tk
from tkinter import messagebox
from tkinter import *

class Book: # python class book represent the attributes 
    def __init__(self, title, author, publisher, num_pages, is_hard_copy, is_ebook): # book attribute initialise 
        self.title = title
        self.author = author
        self.publisher = publisher
        self.num_pages = num_pages
        self.is_hard_copy = is_hard_copy
        self.is_ebook = is_ebook

def create_book(): # create book instance from user 
    title:str = title_entry.get() # retrieve user input from GUI input fields 
    author:str = author_e.get()
    publisher:str = publisher_e.get()
    num_pages:int = num_pages_entry.get()
    is_hard_copy = hard_copy_var.get()
    is_ebook = ebook_var.get()

    book = Book(title, author, publisher, num_pages, is_hard_copy, is_ebook) # create book instance based on user provided data 
    book_info(book) # display book information 

def book_info(book): # define display information in a messagebox 
    v1 = []
    if book.is_hard_copy: # hard_copy or ebook check 
        v1.append("Hard Copy")
    if book.is_ebook:
        v1.append("Ebook")

    v1_str = ', '.join(v1)  
    details = f"Title: {book.title}\nAuthor: {book.author}\nPublisher: {book.publisher}\nNumber of Pages: {book.num_pages}\nVersion(s): {v1_str}"
    messagebox.showinfo("Book Information", details) 

# GUI setup
window = tk.Tk()
window.title("Book Information")

# Create and configure input fields
title_label = Label(window, text="Title:")
title_label.pack()
title_entry = Entry(window)
title_entry.pack()

author_label = Label(window, text="Author full name:")
author_label.pack()
author_e = tk.Entry(window)
author_e.pack()

publisher_label = Label(window, text="Publisher name:")
publisher_label.pack()
publisher_e = Entry(window)
publisher_e.pack()

num_pages_label = Label(window, text="Number of Pages:")
num_pages_label.pack()
num_pages_entry = Entry(window)
num_pages_entry.pack()

hard_copy_var = tk.BooleanVar()
hard_copy_check = tk.Checkbutton(window, text="Hard Copy", variable=hard_copy_var)
hard_copy_check.pack()

ebook_var = tk.BooleanVar()
ebook_check = tk.Checkbutton(window, text="Ebook", variable=ebook_var)
ebook_check.pack()

create_button = Button(window, text="Book Details", command=create_book)
create_button.pack()

window.mainloop()
